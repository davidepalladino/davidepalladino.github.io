 /**
  * This software allows to manage the hardware of "LED Controller". Specifically, you can manage the red, green and blue color, and the global intensity. 
  * If you want you can save or read the configuration in SD card; for this, you have three slot.
  * Copyright (c) 2020 Davide Palladino. 
  * All right reserved.
  * 
  * @author Davide Palladino
  * @contact davidepalladino@hotmail.com
  * @version 1.0
  * @date 11th July, 2020
  * 
  */

#include <Arduino.h>
#include <SD.h>
#include <SPI.h>
#include <EEPROM.h>

#include <AnalogIO.h>
#include <Button.h>
#include <Profile.h>

#include "config.h"

/* Creating of the objects for managing the encoders and the strip led. */
AnalogIn encoderIntensity(pinAEncoderIntensity, pinBEncoderIntensity, BIT6);
AnalogController intensity(&encoderIntensity, NULL);

AnalogIn encoderRed(pinAEncoderRed, pinBEncoderRed, BIT6);
AnalogOut ledStripRed(pinLedStripRed);
AnalogController red(&encoderRed, &ledStripRed);

AnalogIn encoderGreen(pinAEncoderGreen, pinBEncoderGreen, BIT6);
AnalogOut ledStripGreen(pinLedStripGreen);
AnalogController green(&encoderGreen, &ledStripGreen);

AnalogIn encoderBlue(pinAEncoderBlue, pinBEncoderBlue, BIT6);
AnalogOut ledStripBlue(pinLedStripBlue);
AnalogController blue(&encoderBlue, &ledStripBlue);

/* Creating of the objects for managing the leds status. */
AnalogOut ledSingleRed(pinLedSingleRed);
AnalogController errorNotice(NULL, &ledSingleRed);

AnalogOut ledSingleGreen(pinLedSingleGreen);
AnalogController successNotice(NULL, &ledSingleGreen);

/* Creating of the objects for the buttons. */
Button buttonProfile1(pinButtonProfile1, timeLongPress);
Button buttonProfile2(pinButtonProfile2, timeLongPress);
Button buttonProfile3(pinButtonProfile3, timeLongPress);

/* Creating the main profile for managing the previous objects. */
Profile mainProfile(&intensity, &red, &green, &blue);

/* Creating a variabile that will contain the number of the select profile, for reading/writing the values. */
int8_t selectProfile;      // -1 stands for not set.

/* Creating a variabile that will contain the select file, for reading/writing the values. */
String selectNameFile;

/* Creating a variable that will contain the number of status of any button. */
int8_t statusButton;

/* Creating a variable to prevent a continuos "long press" of the button. */
bool alreadyPressedButton;

/* Creating the variable to manage the saving of manual configuration. */
unsigned long endTimeout;       // This will contain the time where thew manual configuration will be saved on "fileNameManual".
bool timeStarted = false;       // This indicate if the time is started or not.
bool saveManual = false;        // This indicate if the values will be saved or not.

void setup() {
  //Serial.begin(baudRate);     // For debugging. You will have to insert the methods of Serial.

  /* Setting the speed for the encoders. */
  intensity.setSpeed(speedIntensity);
  red.setSpeed(speedRed);
  green.setSpeed(speedGreen);
  blue.setSpeed(speedBlue);
  
  /* Getting the number of last profile read/written from EEPROM. */
  EEPROM.get(addressEEPROMNumProfile, selectProfile);

  /* Setting the "selectNameFile" based on the value of "selectProfile". */
  switch(selectProfile) {
    case 0:
      selectNameFile = fileNameManual;
      break;
    case 1:
      selectNameFile = fileNameProfile1;
      break;
    case 2:
      selectNameFile = fileNameProfile2;
      break;
    case 3:
      selectNameFile = fileNameProfile3;
      break;
  }

  /* Resetting of "selectProfile". */
  selectProfile = -1;

  /* Loading the profile from SD card. */
  SD.begin(pinCS);

  if (mainProfile.readFile(selectNameFile)) {
    successNotice.blink(timesBlinkReadProfile, timeoutBlinkReadProfile);
  } else {
    errorNotice.blink(timesBlinkError, timeoutBlinkError);
  }

  SD.end();

  /* Writing the new values to the device. */
  mainProfile.writeDevice();
}

void loop() {
  /* Reading from the device and if there will be a change than before, 
   * will start the timeout by which is possible to an another change without saves it, 
   * resetting the timeout.
   */
  if (mainProfile.readDevice()) {
    endTimeout = millis() + timeoutSaveManual;
    timeStarted = true;
  }

  /* Checking if the timeout is ended, where the variables "saveManual" will be changed for the next saving. */
  if ((millis() > endTimeout) && timeStarted) {
    selectProfile = 0;
    saveManual = true;
  }

  /* Reading the status only on one of the buttons and setting of "selectProfile". */
  if ((statusButton = buttonProfile1.checkPress()) != 0) {
    selectProfile = 1;
  } else if ((statusButton = buttonProfile2.checkPress()) != 0) {
    selectProfile = 2;
  } else if ((statusButton = buttonProfile3.checkPress()) != 0) {
    selectProfile = 3;
  }

  /* Setting the "selectNameFile" based on the value of "selectProfile". */
  switch(selectProfile) {
    case 0:
      selectNameFile = fileNameManual;
      break;
    case 1:
      selectNameFile = fileNameProfile1;
      break;
    case 2:
      selectNameFile = fileNameProfile2;
      break;
    case 3:
      selectNameFile = fileNameProfile3;
      break;      
  }

  /* Storing the number of last profile on the EEPROM and resetting of "selectProfile" and "timeStarted". */
  if (selectProfile != -1) {
      EEPROM.update(addressEEPROMNumProfile, selectProfile);

      selectProfile = -1;
      timeStarted = false;
  }

  /* Checking of the operation based on the "statusButton". For every one, "saveManual" will be set to false". */
  if (statusButton == 1) {
    saveManual = false;

    /* Loading the profile from SD card. */
    SD.begin(pinCS);

    if (mainProfile.readFile(selectNameFile)) {
      successNotice.blink(timesBlinkReadProfile, timeoutBlinkReadProfile);
    } else {
      errorNotice.blink(timesBlinkError, timeoutBlinkError);
    }

    SD.end();
  } else if (((statusButton == -1) && !alreadyPressedButton) || saveManual) {
    saveManual = false;

    /* Saving the profile to SD card. */
    SD.begin(pinCS);

    if (mainProfile.saveFile(selectNameFile)) {
      successNotice.blink(timesBlinkSaveProfile, timeoutBlinkSaveProfile);
    } else {
      errorNotice.blink(timesBlinkError, timeoutBlinkError);
    }

    SD.end();

    alreadyPressedButton = true;
  } else if (statusButton == 0) {
    alreadyPressedButton = false;
  }

  /* Writing the new values to the device. */
  mainProfile.writeDevice();
}