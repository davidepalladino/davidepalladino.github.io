/* Setting the input and output pins about the encoders and the strip led, and the speeds for the encoders */
// Intensity
const uint8_t pinAEncoderIntensity = A0;
const uint8_t pinBEncoderIntensity = A1;
const uint8_t speedIntensity = 1;

// Red
const uint8_t pinAEncoderRed = A2;
const uint8_t pinBEncoderRed = A3;
const uint8_t pinLedStripRed = 5;
const uint8_t speedRed = 1;

// Green
const uint8_t pinAEncoderGreen = A4;
const uint8_t pinBEncoderGreen = A5;
const uint8_t pinLedStripGreen = 6;
const uint8_t speedGreen = 1;

// Blue
const uint8_t pinAEncoderBlue = A6;
const uint8_t pinBEncoderBlue = A7;
const uint8_t pinLedStripBlue = 3;
const uint8_t speedBlue = 1;

/* Setting the output pins about the single led, the times and timeout for blink. */
const uint8_t pinLedSingleRed = 9;
const uint8_t pinLedSingleGreen = 10;
const uint8_t timesBlinkError = 1;
const uint16_t timeoutBlinkError = 500;
const uint8_t timesBlinkReadProfile = 1;
const uint16_t timeoutBlinkReadProfile = 1000;
const uint8_t timesBlinkSaveProfile = 3;
const uint8_t timeoutBlinkSaveProfile = 200;

/* Setting the input pins and the time for the long press about the buttons. */
const uint8_t pinButtonProfile1 = 2;
const uint8_t pinButtonProfile2 = 4;
const uint8_t pinButtonProfile3 = 7;
const uint16_t timeLongPress = 3000;

/* Setting the baudrate for Serial Monitor. */
const uint32_t baudRate = 9600;

/* Setting the card reader and the namefiles. */
const uint8_t pinCS = 8;
const String fileNameManual = "manual.dat"; 
const String fileNameProfile1 = "profile1.dat";
const String fileNameProfile2 = "profile2.dat";
const String fileNameProfile3 = "profile3.dat";
const uint16_t timeoutSaveManual = 5000;

/* Setting the address where saving the number og last profile read/wrote. */
const uint8_t addressEEPROMNumProfile = 0;