#include "Profile.h"

Profile::Profile(AnalogController* intensityObj, AnalogController* redObj, AnalogController* greenObj, AnalogController* blueObj) {
    setIntensityObj(intensityObj);
    setRedObj(redObj);
    setGreenObj(greenObj);
    setBlueObj(blueObj);
}

uint8_t Profile::readFile(String nameFile) {
    /* Converting String type to Char type. */
    const uint8_t sizeNameFileTemp = nameFile.length() + 1;
    char nameFileTemp[sizeNameFileTemp];
    nameFile.toCharArray(nameFileTemp, sizeNameFileTemp);

    /* Creating an array for contains the value read. */
    byte values[nValues] = {0};

    /* Creating the object file. */
    File myFile = SD.open(nameFileTemp);

    /* Reading the values and returning the result of the operation. */
    if (myFile) {
        myFile.read(values, nValues);
        myFile.close();

        getIntensityObj()->setValue((int32_t) values[0]);
        getRedObj()->setValue((int32_t) values[1]);
        getGreenObj()->setValue((int32_t) values[2]);
        getBlueObj()->setValue((int32_t) values[3]);

        return 1;
    } else {
        return 0;
    }
}

uint8_t Profile::saveFile(String nameFile) {
    /* Converting String type to Char type. */
    const uint8_t sizeNameFileTemp = nameFile.length() + 1;
    char nameFileTemp[sizeNameFileTemp];
    nameFile.toCharArray(nameFileTemp, sizeNameFileTemp);

    /* Creating an array for contains the value read. */
    byte values[nValues] = {(byte) getIntensityObj()->getValue(), (byte) getRedObj()->getValue(), (byte) getGreenObj()->getValue(), (byte) getBlueObj()->getValue()};

    /* Checking if "nameFile" is already exists and in this case will be deleted. */
    if (SD.exists(nameFileTemp)) {
        SD.remove(nameFileTemp);
    }

    /* Creating the object file. */
    File myFile = SD.open(nameFileTemp, FILE_WRITE);

    /* Reading the values and returning the result of the operation. */
    if (myFile) {
        myFile.write(values, nValues);
        myFile.close();

        return 1;
    } else {
        return 0;
    }
}

uint8_t Profile::readDevice() {
    /* Saving the actual values for the next comparison. */
    int32_t intensityTemp = getIntensityObj()->getValue();
    int32_t redTemp = getRedObj()->getValue();
    int32_t greenTemp = getGreenObj()->getValue();
    int32_t blueTemp = getBlueObj()->getValue();

    /* Reading the new values from devices. */
    getIntensityObj()->readValue();
    getRedObj()->readValue();
    getGreenObj()->readValue();
    getBlueObj()->readValue();

    /* Checking if there is a change. */
    if ((intensityTemp != getIntensityObj()->getValue()) || (redTemp != getRedObj()->getValue()) || (greenTemp != getGreenObj()->getValue()) || (blueTemp != getBlueObj()->getValue())) {
        return 1;
    } else {
        return 0;
    }
}

void Profile::writeDevice() {
    double percent = (getIntensityObj()->getValue() * 100) / getIntensityObj()->getMaxValueIn();

    getRedObj()->writeValue(percent);
    getGreenObj()->writeValue(percent);
    getBlueObj()->writeValue(percent);
}

void Profile::setIntensityObj(AnalogController* intensityObj) { this->intensityObj = intensityObj; }

void Profile::setRedObj(AnalogController* redObj) { this->redObj = redObj; }

void Profile::setGreenObj(AnalogController* greenObj) { this->greenObj = greenObj; }

void Profile::setBlueObj(AnalogController* blueObj) { this->blueObj = blueObj; }

AnalogController* Profile::getIntensityObj() { return this->intensityObj; }

AnalogController* Profile::getRedObj() { return this->redObj; }

AnalogController* Profile::getGreenObj() { return this->greenObj; }

AnalogController* Profile::getBlueObj() { return this->blueObj; }