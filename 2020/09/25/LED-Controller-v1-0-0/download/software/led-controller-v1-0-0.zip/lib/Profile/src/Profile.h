 /**
  * This library allows to manage the three colors and the intensity.
  * Copyright (c) 2020 Davide Palladino. 
  * All right reserved.
  * 
  * @author Davide Palladino
  * @contact davidepalladino@hotmail.com
  * @version 1.0
  * @date 27th June, 2020
  * 
  * This library is free software; you can redistribute it and/or
  *  modify it under the terms of the GNU General Public
  *  License as published by the Free Software Foundation; either
  *  version 3.0 of the License, or (at your option) any later version
  * 
  * This library is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
  *  GNU Lesser General Public License for more details.
  * 

  */

#ifndef PROFILE_H
    #define PROFILE_H
    #ifndef ARDUINO_H
        #include <Arduino.h>             // Import the Arduino library.
    #endif

    #ifndef SD_H
        #include <SD.h>                  // Import the SD library.
    #endif

     #ifndef SPI_H
        #include <SPI.h>                 // Import the SPI library.
    #endif

    #ifndef ANALOGIO_H
        #include <AnalogIO.h>            // Import the AnalogIO library.
    #endif

    const uint8_t nValues = 4;

    /**
     * Class for initialize and manage the button object.
     */
    class Profile {
        public:            
            /** 
             * This constructor creates the object, setting the pointers to the objects where the colors and the intensity will be read and written.
             * @param intensityObj Pointer to object where will be read the intensity.
             * @param redObj Pointer to object where will be read and written the red color.
             * @param greenObj Pointer to object where will be read and written the green color.
             * @param blueObj Pointer to object where will be read and written the blue color.
             * @warning: The pointers will have not to be "NULL".
             */
            Profile(AnalogController* intensityObj, AnalogController* redObj, AnalogController* greenObj, AnalogController* blueObj);

            /**
             * This method reads the values from a file.
             * @param nameFile Name of file where the values will be read.
             * @return Value 1 if the reading was successful; else value 0.
             */
            uint8_t readFile(String nameFile);

            /**
             * This method saves the values to a file.
             * @param nameFile Name of file where the values will be saved.
             * @return Value 1 if the saving was successful; else value 0.
             */
            uint8_t saveFile(String nameFile);

            /**
             * This method reads the values from the controller objects.
             * @return Value 1 if there is a change compared to the last read; else value 0.
             */
            uint8_t readDevice();

            /**
             * This method reads the values from the controller objects.
             */
            void writeDevice();

        private:
            AnalogController* intensityObj;                // Pointer to object where the intensity will be read and written.
            AnalogController* redObj;                      // Pointer to object where the red color will be read and written.
            AnalogController* greenObj;                    // Pointer to object where the green color will be read and written.
            AnalogController* blueObj;                     // Pointer to object where the blue color will be read and written.

            /**
             * This method sets the pointer to the object where the intensity will be read.
             * @param intensityObj Pointer to object where the intensity will be read.
             */
            void setIntensityObj(AnalogController* intensityObj);

            /**
             * This method sets the pointer to object where the red color will be read and written.
             * @param redObj Pointer to object where the red color will be read and written.
             */
            void setRedObj(AnalogController* redObj);

            /**
             * This method sets the pointer to object where the green color will be read and written.
             * @param greenObj Pointer to object where the green color will be read and written.
             */
            void setGreenObj(AnalogController* greenObj);

            /**
             * This method sets the pointer to object where the blue color will be read and written.
             * @param blueObj Pointer to object where the blue color will be read and written.
             */
            void setBlueObj(AnalogController* blueObj);

            /**
             * This method gets the pointer to object where the intensity will be read.
             * @return Pointer to object.
             */
            AnalogController* getIntensityObj();

            /**
             * This method gets the pointer to object where the red color will be read and written.
             * @return Pointer to object.
             */
            AnalogController* getRedObj();

            /**
             * This method gets the pointer to object where the green color will be read and written.
             * @return Pointer to object.
             */
            AnalogController* getGreenObj();

            /**
             * This method gets the pointer to object where the blue color will be read and written.
             * @return Pointer to object.
             */
            AnalogController* getBlueObj();
    };
#endif